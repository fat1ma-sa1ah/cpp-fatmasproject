"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { GraduationCap, Award, Star, Phone, Mail, Cat, Dog, Bird } from "lucide-react";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const doctors = [
  {
    ar: { name: "د. أحمد العلي", specialty: "طب باطني بيطري", exp: "12 سنة خبرة", bio: "متخصص في الأمراض الباطنية للقطط والكلاب. حاصل على دكتوراه في الطب البيطري." },
    en: { name: "Dr. Ahmed Al-Ali", specialty: "Internal Veterinary Medicine", exp: "12 Years Experience", bio: "Specialized in internal diseases for cats and dogs. PhD in Veterinary Medicine." },
    icon: Cat, color: "from-[#228B22] to-[#2D8F4E]", rating: 4.9,
  },
  {
    ar: { name: "د. سارة الموسوي", specialty: "جراحة بيطرية", exp: "8 سنوات خبرة", bio: "متخصصة في العمليات الجراحية الدقيقة. خريجة جامعة بغداد." },
    en: { name: "Dr. Sara Al-Moussawi", specialty: "Veterinary Surgery", exp: "8 Years Experience", bio: "Specialized in precision surgeries. Graduate of Baghdad University." },
    icon: Dog, color: "from-[#5CACDE] to-[#87CEEB]", rating: 4.8,
  },
  {
    ar: { name: "د. حسين الكربلائي", specialty: "طب الطيور", exp: "10 سنوات خبرة", bio: "متخصص في أمراض الطيور والحيوانات الصغيرة. عضو الجمعية البيطرية العراقية." },
    en: { name: "Dr. Hussein Al-Karbalaei", specialty: "Avian Medicine", exp: "10 Years Experience", bio: "Specialized in bird and small animal diseases. Member of Iraqi Veterinary Association." },
    icon: Bird, color: "from-[#D4922A] to-[#F0B84D]", rating: 4.7,
  },
  {
    ar: { name: "د. زينب الحسني", specialty: "أشعة وتشخيص", exp: "6 سنوات خبرة", bio: "متخصصة في التشخيص بالأشعة السينية والموجات فوق الصوتية. خبيرة في التصوير الطبي البيطري." },
    en: { name: "Dr. Zainab Al-Hassani", specialty: "Radiology & Diagnostics", exp: "6 Years Experience", bio: "Specialized in X-ray and ultrasound diagnostics. Expert in veterinary medical imaging." },
    icon: Cat, color: "from-[#7C3AED] to-[#A78BFA]", rating: 4.9,
  },
  {
    ar: { name: "د. علي الشمري", specialty: "طب الطوارئ البيطري", exp: "15 سنة خبرة", bio: "متخصص في حالات الطوارئ والعناية المركزة. رئيس قسم الطوارئ في العيادة." },
    en: { name: "Dr. Ali Al-Shamri", specialty: "Emergency Vet Medicine", exp: "15 Years Experience", bio: "Specialized in emergency and intensive care. Head of emergency department." },
    icon: Dog, color: "from-[#E11D48] to-[#FB7185]", rating: 4.8,
  },
];

export default function DoctorsPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      <section className="pt-32 pb-24 blob-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-4"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "فريقنا الطبي" : "Our Medical Team"}
            </motion.h1>
            <p className="text-[#5A6B5C] max-w-2xl mx-auto">
              {t ? "فريق من أفضل الأطباء البيطريين المتخصصين في رعاية حيوانك الأليف" : "A team of the best specialized veterinarians caring for your beloved pets"}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {doctors.map((doc, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-[#D4C9A8]/30 group"
              >
                {/* Header with gradient */}
                <div className={`bg-gradient-to-br ${doc.color} p-8 relative overflow-hidden`}>
                  <div className="absolute top-4 left-4 flex items-center gap-1 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1">
                    <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                    <span className="text-white text-xs font-bold">{doc.rating}</span>
                  </div>
                  <div className="flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <doc.icon className="w-10 h-10 text-white" />
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-[#2C3E2D] mb-1" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                    {t ? doc.ar.name : doc.en.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-3">
                    <GraduationCap className="w-4 h-4 text-[#228B22]" />
                    <span className="text-[#228B22] text-sm font-medium">
                      {t ? doc.ar.specialty : doc.en.specialty}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mb-4">
                    <Award className="w-4 h-4 text-[#D4922A]" />
                    <span className="text-[#5A6B5C] text-sm">
                      {t ? doc.ar.exp : doc.en.exp}
                    </span>
                  </div>
                  <p className="text-[#5A6B5C] text-sm leading-relaxed mb-4">
                    {t ? doc.ar.bio : doc.en.bio}
                  </p>
                  <div className="flex gap-2">
                    <button className="flex-1 py-2 rounded-xl bg-[#228B22]/10 text-[#228B22] text-sm font-medium hover:bg-[#228B22]/20 transition-colors cursor-pointer flex items-center justify-center gap-1">
                      <Phone className="w-3.5 h-3.5" />
                      {t ? "اتصل" : "Call"}
                    </button>
                    <button className="flex-1 py-2 rounded-xl bg-[#87CEEB]/20 text-[#5CACDE] text-sm font-medium hover:bg-[#87CEEB]/30 transition-colors cursor-pointer flex items-center justify-center gap-1">
                      <Mail className="w-3.5 h-3.5" />
                      {t ? "راسل" : "Email"}
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer lang={lang} />
    </div>
  );
}

