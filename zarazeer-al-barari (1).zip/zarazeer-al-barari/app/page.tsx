"use client";
import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  PawPrint, Stethoscope, Syringe, Scissors, MessageCircle,
  Heart, Clock, Shield, Star, ArrowLeft, ArrowRight,
  Cat, Dog, Bird, ChevronDown
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function HomePage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";
  const Arrow = t ? ArrowLeft : ArrowRight;

  const services = [
    {
      icon: Stethoscope,
      ar: { title: "الفحص العام", desc: "فحص شامل لصحة حيوانك الأليف" },
      en: { title: "General Checkup", desc: "Comprehensive health examination for your pet" },
      color: "from-[#228B22] to-[#2D8F4E]",
    },
    {
      icon: Syringe,
      ar: { title: "التطعيم", desc: "تطعيمات وقائية لحماية حيوانك" },
      en: { title: "Vaccination", desc: "Preventive vaccines to protect your pet" },
      color: "from-[#5CACDE] to-[#87CEEB]",
    },
    {
      icon: Scissors,
      ar: { title: "العمليات", desc: "عمليات جراحية بأيدي متخصصة" },
      en: { title: "Surgery", desc: "Surgical operations by expert hands" },
      color: "from-[#D4922A] to-[#F0B84D]",
    },
    {
      icon: MessageCircle,
      ar: { title: "الاستشارات", desc: "استشارات بيطرية متخصصة" },
      en: { title: "Consultations", desc: "Expert veterinary consultations" },
      color: "from-[#8B6914] to-[#D4922A]",
    },
  ];

  const stats = [
    { value: "+2000", ar: "حيوان تم علاجه", en: "Pets Treated" },
    { value: "10+", ar: "سنوات خبرة", en: "Years Experience" },
    { value: "5", ar: "أطباء متخصصين", en: "Expert Vets" },
    { value: "98%", ar: "نسبة رضا العملاء", en: "Client Satisfaction" },
  ];

  const features = [
    { icon: Heart, ar: "رعاية بحب", en: "Care with Love", arDesc: "نتعامل مع كل حيوان كأنه فرد من عائلتنا", enDesc: "We treat every pet as part of our family" },
    { icon: Clock, ar: "خدمة سريعة", en: "Fast Service", arDesc: "مواعيد مرنة وخدمة سريعة بدون انتظار", enDesc: "Flexible schedules and fast service without waiting" },
    { icon: Shield, ar: "أمان وثقة", en: "Safe & Trusted", arDesc: "معدات حديثة وفريق موثوق", enDesc: "Modern equipment and a trusted team" },
    { icon: Star, ar: "جودة عالية", en: "High Quality", arDesc: "أفضل الممارسات البيطرية العالمية", enDesc: "Best global veterinary practices" },
  ];

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      {/* Hero Section */}
      <section className="relative pt-20 min-h-[90vh] flex items-center blob-bg overflow-hidden">
        {/* Decorative blobs */}
        <div className="absolute top-32 left-10 w-72 h-72 bg-[#87CEEB]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#228B22]/8 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#F5ECD7]/30 rounded-full blur-3xl" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#228B22]/10 text-[#228B22] text-sm font-medium mb-6">
                <PawPrint className="w-4 h-4" />
                {t ? "مرحباً بكم في عيادتنا" : "Welcome to Our Clinic"}
              </div>
              <h1
                className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#2C3E2D] leading-tight mb-6"
                style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
              >
                {t ? (
                  <>زرازير <span className="text-[#228B22]">البراري</span></>
                ) : (
                  <>Zarazeer <span className="text-[#228B22]">Al-Barari</span></>
                )}
              </h1>
              <p className="text-lg text-[#5A6B5C] leading-relaxed mb-8 max-w-lg">
                {t
                  ? "عيادة بيطرية متخصصة تقدم أفضل الخدمات لحيوانك الأليف. نحن نهتم بصحة حيوانك كما تهتم أنت."
                  : "A specialized veterinary clinic offering the best services for your pet. We care about your pet's health as much as you do."}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/booking">
                  <Button className="bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer">
                    {t ? "احجز موعدك الآن" : "Book Your Appointment"}
                    <Arrow className="w-5 h-5 mr-2" />
                  </Button>
                </Link>
                <Link href="/services">
                  <Button
                    variant="outline"
                    className="border-2 border-[#228B22] text-[#228B22] hover:bg-[#228B22]/10 rounded-2xl px-8 py-6 text-lg transition-all duration-300 cursor-pointer"
                  >
                    {t ? "تعرف على خدماتنا" : "Explore Our Services"}
                  </Button>
                </Link>
              </div>
            </motion.div>

            {/* Hero Illustration */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden md:flex justify-center"
            >
              <div className="relative w-96 h-96">
                <div className="absolute inset-0 bg-gradient-to-br from-[#228B22]/20 to-[#87CEEB]/20 rounded-[3rem] rotate-6" />
                <div className="absolute inset-0 bg-gradient-to-br from-[#F5ECD7] to-[#FFF8ED] rounded-[3rem] flex items-center justify-center shadow-2xl">
                  <div className="text-center">
                    <div className="flex justify-center gap-4 mb-6">
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 2, delay: 0 }}
                        className="w-16 h-16 rounded-2xl bg-[#228B22]/10 flex items-center justify-center"
                      >
                        <Cat className="w-8 h-8 text-[#228B22]" />
                      </motion.div>
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 2, delay: 0.3 }}
                        className="w-16 h-16 rounded-2xl bg-[#87CEEB]/20 flex items-center justify-center"
                      >
                        <Dog className="w-8 h-8 text-[#5CACDE]" />
                      </motion.div>
                      <motion.div
                        animate={{ y: [0, -8, 0] }}
                        transition={{ repeat: Infinity, duration: 2, delay: 0.6 }}
                        className="w-16 h-16 rounded-2xl bg-[#D4922A]/10 flex items-center justify-center"
                      >
                        <Bird className="w-8 h-8 text-[#D4922A]" />
                      </motion.div>
                    </div>
                    <PawPrint className="w-20 h-20 text-[#228B22]/30 mx-auto" />
                    <p className="text-[#228B22] font-bold text-lg mt-4" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                      {t ? "رعاية متكاملة" : "Complete Care"}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Scroll indicator */}
          <motion.div
            className="flex justify-center mt-16"
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ChevronDown className="w-6 h-6 text-[#228B22]/40" />
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-[#228B22] to-[#2D8F4E] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl sm:text-4xl font-bold text-white mb-2" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                  {stat.value}
                </div>
                <p className="text-white/80 text-sm">{t ? stat.ar : stat.en}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 relative blob-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-4"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "خدماتنا" : "Our Services"}
            </motion.h2>
            <p className="text-[#5A6B5C] max-w-2xl mx-auto">
              {t
                ? "نقدم مجموعة شاملة من الخدمات البيطرية لضمان صحة وسعادة حيوانك الأليف"
                : "We offer a comprehensive range of veterinary services to ensure your pet's health and happiness"}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-[#D4C9A8]/30 cursor-pointer group"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-[#2C3E2D] mb-3" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                  {t ? service.ar.title : service.en.title}
                </h3>
                <p className="text-[#5A6B5C] text-sm leading-relaxed">
                  {t ? service.ar.desc : service.en.desc}
                </p>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button
                variant="outline"
                className="border-2 border-[#228B22] text-[#228B22] hover:bg-[#228B22]/10 rounded-2xl px-8 py-4 text-base transition-all duration-300 cursor-pointer"
              >
                {t ? "عرض جميع الخدمات" : "View All Services"}
                <Arrow className="w-4 h-4 mr-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-[#F5ECD7]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-4"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "لماذا تختارنا؟" : "Why Choose Us?"}
            </motion.h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center group"
              >
                <div className="w-16 h-16 rounded-full bg-white shadow-lg flex items-center justify-center mx-auto mb-4 group-hover:shadow-xl group-hover:scale-110 transition-all duration-300">
                  <feature.icon className="w-7 h-7 text-[#228B22]" />
                </div>
                <h3 className="text-lg font-bold text-[#2C3E2D] mb-2" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                  {t ? feature.ar : feature.en}
                </h3>
                <p className="text-[#5A6B5C] text-sm">{t ? feature.arDesc : feature.enDesc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#228B22]/5 to-[#87CEEB]/10" />
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="w-20 h-20 rounded-full bg-[#228B22]/10 flex items-center justify-center mx-auto mb-8">
              <PawPrint className="w-10 h-10 text-[#228B22]" />
            </div>
            <h2
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-6"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "حيوانك يستحق الأفضل" : "Your Pet Deserves the Best"}
            </h2>
            <p className="text-[#5A6B5C] text-lg mb-10 max-w-2xl mx-auto">
              {t
                ? "احجز موعدك الآن ودع فريقنا المتخصص يعتني بصحة حيوانك الأليف"
                : "Book your appointment now and let our expert team take care of your pet's health"}
            </p>
            <Link href="/booking">
              <Button className="bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl px-10 py-6 text-lg shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer">
                {t ? "احجز الآن" : "Book Now"}
                <Arrow className="w-5 h-5 mr-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      <Footer lang={lang} />
    </div>
  );
}


