"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  LayoutDashboard, CalendarDays, Users, PawPrint,
  Plus, Pencil, Trash2, CheckCircle, Clock, XCircle,
  Cat, Dog, Bird, Rabbit, TrendingUp, Activity,
  LogOut, Bell
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

type Booking = {
  id: number;
  name: string;
  phone: string;
  pet: string;
  petIcon: typeof Cat;
  date: string;
  time: string;
  status: "confirmed" | "pending" | "cancelled";
};

const initialBookings: Booking[] = [
  { id: 1, name: "أحمد محمد", phone: "0770 111 2233", pet: "قطة", petIcon: Cat, date: "2025-06-15", time: "09:00", status: "confirmed" },
  { id: 2, name: "سارة علي", phone: "0771 222 3344", pet: "كلب", petIcon: Dog, date: "2025-06-15", time: "10:00", status: "pending" },
  { id: 3, name: "حسين كريم", phone: "0772 333 4455", pet: "طائر", petIcon: Bird, date: "2025-06-16", time: "11:00", status: "confirmed" },
  { id: 4, name: "زينب حسن", phone: "0773 444 5566", pet: "أرنب", petIcon: Rabbit, date: "2025-06-16", time: "13:00", status: "cancelled" },
  { id: 5, name: "علي جاسم", phone: "0774 555 6677", pet: "قطة", petIcon: Cat, date: "2025-06-17", time: "09:30", status: "pending" },
  { id: 6, name: "مريم عبدالله", phone: "0775 666 7788", pet: "كلب", petIcon: Dog, date: "2025-06-17", time: "14:00", status: "confirmed" },
];

const statusConfig = {
  confirmed: { icon: CheckCircle, label: "مؤكد", color: "bg-emerald-100 text-emerald-700", dot: "bg-emerald-500" },
  pending: { icon: Clock, label: "بانتظار", color: "bg-amber-100 text-amber-700", dot: "bg-amber-500" },
  cancelled: { icon: XCircle, label: "ملغي", color: "bg-red-100 text-red-700", dot: "bg-red-500" },
};

export default function DashboardPage() {
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [activeTab, setActiveTab] = useState("all");

  const stats = [
    { label: "إجمالي الحجوزات", value: bookings.length, icon: CalendarDays, color: "from-[#228B22] to-[#2D8F4E]" },
    { label: "المؤكدة", value: bookings.filter(b => b.status === "confirmed").length, icon: CheckCircle, color: "from-[#059669] to-[#34D399]" },
    { label: "بانتظار", value: bookings.filter(b => b.status === "pending").length, icon: Clock, color: "from-[#D4922A] to-[#F0B84D]" },
    { label: "الملغاة", value: bookings.filter(b => b.status === "cancelled").length, icon: XCircle, color: "from-[#DC2626] to-[#F87171]" },
  ];

  const filtered = activeTab === "all" ? bookings : bookings.filter(b => b.status === activeTab);

  const toggleStatus = (id: number) => {
    setBookings(prev => prev.map(b => {
      if (b.id !== id) return b;
      const next = b.status === "pending" ? "confirmed" : b.status === "confirmed" ? "cancelled" : "pending";
      return { ...b, status: next as Booking["status"] };
    }));
  };

  const deleteBooking = (id: number) => {
    setBookings(prev => prev.filter(b => b.id !== id));
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#F5ECD7]/30">
      {/* Sidebar */}
      <aside className="fixed top-0 right-0 w-64 h-full bg-[#2C3E2D] text-white z-50 hidden lg:flex flex-col">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#228B22] flex items-center justify-center">
              <PawPrint className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-sm" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>زرازير البراري</h2>
              <p className="text-white/50 text-xs">لوحة التحكم</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { icon: LayoutDashboard, label: "الرئيسية", active: true },
            { icon: CalendarDays, label: "الحجوزات" },
            { icon: Users, label: "المراجعين" },
            { icon: Activity, label: "التقارير" },
          ].map((item, i) => (
            <button
              key={i}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all cursor-pointer ${
                item.active ? "bg-[#228B22] text-white" : "text-white/60 hover:text-white hover:bg-white/5"
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-9 h-9 rounded-full bg-[#228B22]/30 flex items-center justify-center">
              <Users className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium">فاطمة صلاح</p>
              <p className="text-xs text-white/50">مديرة</p>
            </div>
          </div>
          <Link href="/">
            <button className="w-full flex items-center gap-2 px-4 py-2 rounded-xl text-sm text-white/60 hover:text-white hover:bg-white/5 transition-all cursor-pointer">
              <LogOut className="w-4 h-4" />
              خروج
            </button>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:mr-64">
        {/* Top Bar */}
        <header className="bg-white/80 backdrop-blur-lg border-b border-[#D4C9A8]/30 px-6 py-4 flex items-center justify-between sticky top-0 z-40">
          <div>
            <h1 className="text-xl font-bold text-[#2C3E2D]" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
              لوحة التحكم
            </h1>
            <p className="text-sm text-[#5A6B5C]">مرحباً فاطمة، إليكِ ملخص اليوم</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative p-2 rounded-xl hover:bg-[#F5ECD7] transition-colors cursor-pointer">
              <Bell className="w-5 h-5 text-[#5A6B5C]" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500" />
            </button>
            <Link href="/" className="lg:hidden">
              <Button variant="outline" size="sm" className="rounded-xl cursor-pointer">الموقع</Button>
            </Link>
          </div>
        </header>

        <div className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-5 shadow-md border border-[#D4C9A8]/20 hover:shadow-lg transition-shadow"
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-2xl font-bold text-[#2C3E2D]">{stat.value}</p>
                <p className="text-xs text-[#5A6B5C] mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          {/* Bookings Table */}
          <div className="bg-white rounded-3xl shadow-lg border border-[#D4C9A8]/20 overflow-hidden">
            <div className="p-6 border-b border-[#D4C9A8]/20 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-lg font-bold text-[#2C3E2D]" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                إدارة الحجوزات
              </h2>
              <div className="flex gap-2">
                {["all", "confirmed", "pending", "cancelled"].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                      activeTab === tab
                        ? "bg-[#228B22] text-white shadow-md"
                        : "bg-[#F5ECD7]/50 text-[#5A6B5C] hover:bg-[#228B22]/10"
                    }`}
                  >
                    {tab === "all" ? "الكل" : statusConfig[tab as keyof typeof statusConfig].label}
                  </button>
                ))}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#F5ECD7]/30">
                  <tr className="text-[#5A6B5C] text-xs">
                    <th className="text-right py-3 px-6 font-medium">#</th>
                    <th className="text-right py-3 px-6 font-medium">الاسم</th>
                    <th className="text-right py-3 px-6 font-medium">الهاتف</th>
                    <th className="text-right py-3 px-6 font-medium">الحيوان</th>
                    <th className="text-right py-3 px-6 font-medium">التاريخ</th>
                    <th className="text-right py-3 px-6 font-medium">الوقت</th>
                    <th className="text-right py-3 px-6 font-medium">الحالة</th>
                    <th className="text-right py-3 px-6 font-medium">إجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((booking, i) => {
                    const st = statusConfig[booking.status];
                    return (
                      <motion.tr
                        key={booking.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.05 }}
                        className="border-t border-[#D4C9A8]/10 hover:bg-[#FFF8ED]/50 transition-colors"
                      >
                        <td className="py-4 px-6 text-sm text-[#5A6B5C]">{booking.id}</td>
                        <td className="py-4 px-6 text-sm font-medium text-[#2C3E2D]">{booking.name}</td>
                        <td className="py-4 px-6 text-sm text-[#5A6B5C]" dir="ltr">{booking.phone}</td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-2">
                            <booking.petIcon className="w-4 h-4 text-[#228B22]" />
                            <span className="text-sm text-[#2C3E2D]">{booking.pet}</span>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-sm text-[#5A6B5C]">{booking.date}</td>
                        <td className="py-4 px-6 text-sm text-[#5A6B5C]">{booking.time}</td>
                        <td className="py-4 px-6">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${st.color}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${st.dot}`} />
                            {st.label}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => toggleStatus(booking.id)}
                              className="p-2 rounded-lg hover:bg-[#228B22]/10 text-[#228B22] transition-colors cursor-pointer"
                              title="تغيير الحالة"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteBooking(booking.id)}
                              className="p-2 rounded-lg hover:bg-red-50 text-red-500 transition-colors cursor-pointer"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>

              {filtered.length === 0 && (
                <div className="py-12 text-center">
                  <CalendarDays className="w-12 h-12 text-[#D4C9A8] mx-auto mb-3" />
                  <p className="text-[#5A6B5C]">لا توجد حجوزات</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

