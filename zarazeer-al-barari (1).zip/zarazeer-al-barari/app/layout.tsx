import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "زرازير البراري | عيادة بيطرية",
  description: "عيادة بيطرية متخصصة في رعاية الحيوانات - حجز المواعيد والخدمات البيطرية",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Noto+Sans+Arabic:wght@300;400;500;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased grain-overlay" style={{ fontFamily: "'Noto Sans Arabic', sans-serif" }}>
        {children}
      </body>
    </html>
  );
}

