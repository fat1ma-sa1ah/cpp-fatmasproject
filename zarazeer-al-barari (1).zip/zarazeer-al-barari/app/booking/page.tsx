"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Clock, PawPrint, User, Phone, CheckCircle, Cat, Dog, Bird, Rabbit } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const animalTypes = [
  { id: "cat", icon: Cat, ar: "قطة", en: "Cat" },
  { id: "dog", icon: Dog, ar: "كلب", en: "Dog" },
  { id: "bird", icon: Bird, ar: "طائر", en: "Bird" },
  { id: "rabbit", icon: Rabbit, ar: "أرنب", en: "Rabbit" },
];

const timeSlots = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00"];

export default function BookingPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";
  const [selectedAnimal, setSelectedAnimal] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
        <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />
        <div className="pt-32 pb-24 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center max-w-md mx-auto px-4"
          >
            <div className="w-24 h-24 rounded-full bg-[#228B22]/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-[#228B22]" />
            </div>
            <h2 className="text-3xl font-bold text-[#2C3E2D] mb-4" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
              {t ? "تم تأكيد الحجز!" : "Booking Confirmed!"}
            </h2>
            <p className="text-[#5A6B5C] mb-8">
              {t ? "سيتم التواصل معك لتأكيد الموعد. شكراً لثقتك بعيادة زرازير البراري!" : "We'll contact you to confirm the appointment. Thank you for trusting Zarazeer Al-Barari!"}
            </p>
            <Button
              onClick={() => setSubmitted(false)}
              className="bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl px-8 py-4 cursor-pointer"
            >
              {t ? "حجز موعد آخر" : "Book Another"}
            </Button>
          </motion.div>
        </div>
        <Footer lang={lang} />
      </div>
    );
  }

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      <section className="pt-32 pb-24 blob-bg">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="text-center mb-12">
              <div className="w-16 h-16 rounded-2xl bg-[#228B22]/10 flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-[#228B22]" />
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-3" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                {t ? "حجز موعد" : "Book an Appointment"}
              </h1>
              <p className="text-[#5A6B5C]">
                {t ? "املأ النموذج التالي لحجز موعدك" : "Fill the form below to book your appointment"}
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-xl border border-[#D4C9A8]/30">
              <form
                onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
                className="space-y-8"
              >
                {/* Personal Info */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                      <User className="w-4 h-4 inline ml-1" />
                      {t ? "الاسم الكامل" : "Full Name"}
                    </label>
                    <Input
                      required
                      placeholder={t ? "أدخل اسمك" : "Enter your name"}
                      className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                      <Phone className="w-4 h-4 inline ml-1" />
                      {t ? "رقم الهاتف" : "Phone Number"}
                    </label>
                    <Input
                      required
                      type="tel"
                      dir="ltr"
                      placeholder="+964 7XX XXX XXXX"
                      className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12"
                    />
                  </div>
                </div>

                {/* Animal Type */}
                <div>
                  <label className="block text-sm font-medium text-[#2C3E2D] mb-3">
                    <PawPrint className="w-4 h-4 inline ml-1" />
                    {t ? "نوع الحيوان" : "Pet Type"}
                  </label>
                  <div className="grid grid-cols-4 gap-3">
                    {animalTypes.map((animal) => (
                      <button
                        key={animal.id}
                        type="button"
                        onClick={() => setSelectedAnimal(animal.id)}
                        className={`p-4 rounded-2xl border-2 transition-all duration-200 flex flex-col items-center gap-2 cursor-pointer ${
                          selectedAnimal === animal.id
                            ? "border-[#228B22] bg-[#228B22]/10 shadow-md"
                            : "border-[#D4C9A8]/50 hover:border-[#228B22]/50 bg-white"
                        }`}
                      >
                        <animal.icon className={`w-8 h-8 ${selectedAnimal === animal.id ? "text-[#228B22]" : "text-[#5A6B5C]"}`} />
                        <span className={`text-xs font-medium ${selectedAnimal === animal.id ? "text-[#228B22]" : "text-[#5A6B5C]"}`}>
                          {t ? animal.ar : animal.en}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                    <Calendar className="w-4 h-4 inline ml-1" />
                    {t ? "التاريخ" : "Date"}
                  </label>
                  <Input
                    required
                    type="date"
                    className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12"
                  />
                </div>

                {/* Time Slots */}
                <div>
                  <label className="block text-sm font-medium text-[#2C3E2D] mb-3">
                    <Clock className="w-4 h-4 inline ml-1" />
                    {t ? "الوقت" : "Time"}
                  </label>
                  <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                    {timeSlots.map((time) => (
                      <button
                        key={time}
                        type="button"
                        onClick={() => setSelectedTime(time)}
                        className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer ${
                          selectedTime === time
                            ? "bg-[#228B22] text-white shadow-md"
                            : "bg-[#F5ECD7]/50 text-[#2C3E2D] hover:bg-[#228B22]/10"
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Pet Name */}
                <div>
                  <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                    {t ? "اسم الحيوان (اختياري)" : "Pet Name (optional)"}
                  </label>
                  <Input
                    placeholder={t ? "اسم حيوانك الأليف" : "Your pet's name"}
                    className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl py-6 text-lg shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer"
                >
                  {t ? "تأكيد الحجز" : "Confirm Booking"}
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer lang={lang} />
    </div>
  );
}

