"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import {
  Stethoscope, Syringe, Scissors, MessageCircle,
  Microscope, Pill, Bone, HeartPulse, ArrowLeft, ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const allServices = [
  {
    icon: Stethoscope,
    ar: { title: "الفحص العام", desc: "فحص شامل لصحة حيوانك الأليف يشمل فحص القلب والرئتين والأسنان والعيون والأذنين والجلد" },
    en: { title: "General Checkup", desc: "Complete health examination including heart, lungs, teeth, eyes, ears, and skin" },
    color: "from-[#228B22] to-[#2D8F4E]", price: { ar: "15,000 د.ع", en: "15,000 IQD" },
  },
  {
    icon: Syringe,
    ar: { title: "التطعيم", desc: "تطعيمات وقائية ضد الأمراض الشائعة مثل داء الكلب والبارفو والهربس" },
    en: { title: "Vaccination", desc: "Preventive vaccines against common diseases like rabies, parvo, and herpes" },
    color: "from-[#5CACDE] to-[#87CEEB]", price: { ar: "10,000 د.ع", en: "10,000 IQD" },
  },
  {
    icon: Scissors,
    ar: { title: "العمليات الجراحية", desc: "عمليات جراحية متقدمة بأيدي متخصصين ومعدات حديثة" },
    en: { title: "Surgery", desc: "Advanced surgical operations by specialists with modern equipment" },
    color: "from-[#D4922A] to-[#F0B84D]", price: { ar: "حسب الحالة", en: "Case-based" },
  },
  {
    icon: MessageCircle,
    ar: { title: "الاستشارات", desc: "استشارات بيطرية مع أطباء متخصصين حول تغذية وسلوك الحيوان" },
    en: { title: "Consultations", desc: "Expert veterinary consultations on pet nutrition and behavior" },
    color: "from-[#8B6914] to-[#D4922A]", price: { ar: "8,000 د.ع", en: "8,000 IQD" },
  },
  {
    icon: Microscope,
    ar: { title: "الفحوصات المخبرية", desc: "تحاليل دم وبول وفحوصات مخبرية متقدمة" },
    en: { title: "Lab Tests", desc: "Blood, urine tests and advanced laboratory examinations" },
    color: "from-[#7C3AED] to-[#A78BFA]", price: { ar: "20,000 د.ع", en: "20,000 IQD" },
  },
  {
    icon: Pill,
    ar: { title: "الصيدلية", desc: "صيدلية بيطرية متكاملة توفر جميع الأدوية البيطرية" },
    en: { title: "Pharmacy", desc: "Complete veterinary pharmacy with all required medications" },
    color: "from-[#059669] to-[#34D399]", price: { ar: "حسب الدواء", en: "Per medication" },
  },
  {
    icon: Bone,
    ar: { title: "الأشعة", desc: "تصوير بالأشعة السينية لتشخيص الكسور والأمراض الداخلية" },
    en: { title: "X-Ray", desc: "X-ray imaging for diagnosing fractures and internal diseases" },
    color: "from-[#DC2626] to-[#F87171]", price: { ar: "25,000 د.ع", en: "25,000 IQD" },
  },
  {
    icon: HeartPulse,
    ar: { title: "العناية المركزة", desc: "رعاية مركزة للحالات الحرجة والطوارئ على مدار الساعة" },
    en: { title: "Intensive Care", desc: "24/7 intensive care for critical and emergency cases" },
    color: "from-[#E11D48] to-[#FB7185]", price: { ar: "حسب الحالة", en: "Case-based" },
  },
];

export default function ServicesPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";
  const Arrow = t ? ArrowLeft : ArrowRight;

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      <section className="pt-32 pb-24 blob-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-4"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "خدماتنا البيطرية" : "Our Veterinary Services"}
            </motion.h1>
            <p className="text-[#5A6B5C] max-w-2xl mx-auto">
              {t ? "نقدم مجموعة واسعة من الخدمات البيطرية لضمان صحة وراحة حيوانك الأليف" : "We offer a wide range of veterinary services to ensure your pet's health and comfort"}
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {allServices.map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ y: -8 }}
                className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-[#D4C9A8]/30 group cursor-pointer"
              >
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg font-bold text-[#2C3E2D] mb-2" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                  {t ? service.ar.title : service.en.title}
                </h3>
                <p className="text-[#5A6B5C] text-sm leading-relaxed mb-4">
                  {t ? service.ar.desc : service.en.desc}
                </p>
                <div className="pt-4 border-t border-[#D4C9A8]/30">
                  <span className="text-[#228B22] font-bold text-sm">
                    {t ? service.price.ar : service.price.en}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-16">
            <Link href="/booking">
              <Button className="bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl px-10 py-6 text-lg shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer">
                {t ? "احجز موعدك الآن" : "Book Your Appointment"}
                <Arrow className="w-5 h-5 mr-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer lang={lang} />
    </div>
  );
}

