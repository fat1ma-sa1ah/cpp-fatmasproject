"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { PawPrint, User, Lock, Eye, EyeOff, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Navbar from "@/components/navbar";

export default function LoginPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";
  const [showPass, setShowPass] = useState(false);
  const [mode, setMode] = useState<"user" | "admin">("user");
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === "admin") {
      router.push("/dashboard");
    } else {
      router.push("/");
    }
  };

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      <section className="pt-28 pb-24 min-h-screen flex items-center blob-bg">
        <div className="max-w-md mx-auto px-4 w-full relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-8 sm:p-10 shadow-2xl border border-[#D4C9A8]/30"
          >
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#228B22] to-[#2D8F4E] flex items-center justify-center mx-auto mb-4 shadow-lg">
                <PawPrint className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-[#2C3E2D]" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                {t ? "تسجيل الدخول" : "Sign In"}
              </h1>
              <p className="text-[#5A6B5C] text-sm mt-1">
                {t ? "مرحباً بك في عيادة زرازير البراري" : "Welcome to Zarazeer Al-Barari"}
              </p>
            </div>

            {/* Mode Toggle */}
            <div className="flex bg-[#F5ECD7]/60 rounded-2xl p-1 mb-8">
              <button
                onClick={() => setMode("user")}
                className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 ${
                  mode === "user" ? "bg-white text-[#228B22] shadow-md" : "text-[#5A6B5C] hover:text-[#2C3E2D]"
                }`}
              >
                <User className="w-4 h-4" />
                {t ? "مستخدم" : "User"}
              </button>
              <button
                onClick={() => setMode("admin")}
                className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 ${
                  mode === "admin" ? "bg-white text-[#228B22] shadow-md" : "text-[#5A6B5C] hover:text-[#2C3E2D]"
                }`}
              >
                <Shield className="w-4 h-4" />
                {t ? "إدارة" : "Admin"}
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                  <User className="w-4 h-4 inline ml-1" />
                  {t ? "البريد الإلكتروني" : "Email"}
                </label>
                <Input
                  required
                  type="email"
                  placeholder={mode === "admin" ? "admin@zarazeer.iq" : (t ? "بريدك الإلكتروني" : "Your email")}
                  className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#2C3E2D] mb-2">
                  <Lock className="w-4 h-4 inline ml-1" />
                  {t ? "كلمة المرور" : "Password"}
                </label>
                <div className="relative">
                  <Input
                    required
                    type={showPass ? "text" : "password"}
                    placeholder="••••••••"
                    className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12 pl-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-[#5A6B5C] hover:text-[#228B22] cursor-pointer"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl py-5 text-base shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer"
              >
                {t ? "دخول" : "Sign In"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-[#5A6B5C] text-sm">
                {t ? "ليس لديك حساب؟" : "Don't have an account?"}{" "}
                <span className="text-[#228B22] font-medium cursor-pointer hover:underline">
                  {t ? "سجل الآن" : "Register Now"}
                </span>
              </p>
            </div>

            {mode === "admin" && (
              <div className="mt-4 p-3 rounded-xl bg-[#87CEEB]/10 border border-[#87CEEB]/30">
                <p className="text-xs text-[#5CACDE] text-center">
                  {t ? "تلميح: استخدم أي بريد وكلمة مرور للدخول (واجهة تجريبية)" : "Hint: Use any email & password to enter (demo interface)"}
                </p>
              </div>
            )}
          </motion.div>

          <div className="text-center mt-6">
            <Link href="/" className="text-[#5A6B5C] text-sm hover:text-[#228B22] transition-colors cursor-pointer">
              {t ? "← العودة للرئيسية" : "→ Back to Home"}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

