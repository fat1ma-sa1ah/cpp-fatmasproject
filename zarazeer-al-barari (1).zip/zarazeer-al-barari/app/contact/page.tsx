"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

export default function ContactPage() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const t = lang === "ar";
  const [sent, setSent] = useState(false);

  const contactInfo = [
    { icon: Phone, value: "+964 770 123 4567", ar: "رقم الهاتف", en: "Phone" },
    { icon: Mail, value: "info@zarazeer.iq", ar: "البريد الإلكتروني", en: "Email" },
    { icon: MapPin, value: t ? "كربلاء، شارع الحر، بالقرب من ساحة الأمل" : "Karbala, Al-Hur St, Near Amal Square", ar: "العنوان", en: "Address" },
    { icon: Clock, value: t ? "السبت - الخميس: 9 صباحاً - 5 مساءً" : "Sat - Thu: 9 AM - 5 PM", ar: "ساعات العمل", en: "Working Hours" },
  ];

  return (
    <div dir={t ? "rtl" : "ltr"} className="min-h-screen">
      <Navbar lang={lang} onToggleLang={() => setLang(lang === "ar" ? "en" : "ar")} />

      <section className="pt-32 pb-24 blob-bg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl sm:text-4xl font-bold text-[#2C3E2D] mb-4"
              style={{ fontFamily: "'Noto Naskh Arabic', serif" }}
            >
              {t ? "تواصل معنا" : "Contact Us"}
            </motion.h1>
            <p className="text-[#5A6B5C] max-w-2xl mx-auto">
              {t ? "نسعد بتواصلكم معنا. لا تترددوا في الاتصال أو زيارتنا" : "We're happy to hear from you. Don't hesitate to call or visit us"}
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info + Map */}
            <motion.div
              initial={{ opacity: 0, x: t ? 30 : -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="space-y-6 mb-8">
                {contactInfo.map((item, i) => (
                  <div key={i} className="flex items-start gap-4 bg-white rounded-2xl p-5 shadow-md border border-[#D4C9A8]/30 hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 rounded-xl bg-[#228B22]/10 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-[#228B22]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#2C3E2D] text-sm mb-1">{t ? item.ar : item.en}</h3>
                      <p className="text-[#5A6B5C] text-sm" dir={item.icon === Phone ? "ltr" : undefined}>{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Map Placeholder */}
              <div className="rounded-3xl overflow-hidden border border-[#D4C9A8]/30 shadow-lg h-64 bg-gradient-to-br from-[#87CEEB]/20 to-[#228B22]/10 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-[#228B22]/40 mx-auto mb-3" />
                  <p className="text-[#5A6B5C] text-sm font-medium">{t ? "كربلاء، العراق" : "Karbala, Iraq"}</p>
                  <p className="text-[#5A6B5C]/60 text-xs mt-1">{t ? "موقعنا على الخريطة" : "Our location on the map"}</p>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: t ? -30 : 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              {sent ? (
                <div className="bg-white rounded-3xl p-10 shadow-xl border border-[#D4C9A8]/30 flex items-center justify-center min-h-[400px]">
                  <div className="text-center">
                    <div className="w-20 h-20 rounded-full bg-[#228B22]/10 flex items-center justify-center mx-auto mb-6">
                      <Send className="w-9 h-9 text-[#228B22]" />
                    </div>
                    <h3 className="text-2xl font-bold text-[#2C3E2D] mb-3" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                      {t ? "تم إرسال رسالتك!" : "Message Sent!"}
                    </h3>
                    <p className="text-[#5A6B5C] mb-6">{t ? "سنرد عليك في أقرب وقت" : "We'll get back to you soon"}</p>
                    <Button onClick={() => setSent(false)} variant="outline" className="rounded-xl border-[#228B22] text-[#228B22] cursor-pointer">
                      {t ? "إرسال رسالة أخرى" : "Send Another"}
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-xl border border-[#D4C9A8]/30">
                  <h2 className="text-xl font-bold text-[#2C3E2D] mb-6" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                    {t ? "أرسل لنا رسالة" : "Send Us a Message"}
                  </h2>
                  <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="space-y-5">
                    <div>
                      <label className="block text-sm font-medium text-[#2C3E2D] mb-2">{t ? "الاسم الكامل" : "Full Name"}</label>
                      <Input required placeholder={t ? "أدخل اسمك" : "Enter your name"} className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#2C3E2D] mb-2">{t ? "البريد الإلكتروني" : "Email"}</label>
                      <Input required type="email" placeholder={t ? "بريدك الإلكتروني" : "Your email"} className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#2C3E2D] mb-2">{t ? "الموضوع" : "Subject"}</label>
                      <Input required placeholder={t ? "موضوع الرسالة" : "Message subject"} className="rounded-xl border-[#D4C9A8] focus:border-[#228B22] focus:ring-[#228B22] bg-[#FFF8ED]/50 h-12" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#2C3E2D] mb-2">{t ? "الرسالة" : "Message"}</label>
                      <textarea
                        required
                        rows={4}
                        placeholder={t ? "اكتب رسالتك هنا..." : "Write your message here..."}
                        className="w-full rounded-xl border border-[#D4C9A8] focus:border-[#228B22] focus:ring-1 focus:ring-[#228B22] bg-[#FFF8ED]/50 p-3 text-sm resize-none outline-none"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl py-5 text-base shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer">
                      <Send className="w-4 h-4 ml-2" />
                      {t ? "إرسال الرسالة" : "Send Message"}
                    </Button>
                  </form>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      <Footer lang={lang} />
    </div>
  );
}

