"use client";
import { PawPrint, Phone, Mail, MapPin, Heart } from "lucide-react";
import Link from "next/link";

interface FooterProps {
  lang: "ar" | "en";
}

export default function Footer({ lang }: FooterProps) {
  const t = lang === "ar";
  return (
    <footer className="bg-[#2C3E2D] text-white">
      {/* Wave SVG separator */}
      <div className="w-full overflow-hidden leading-none">
        <svg viewBox="0 0 1440 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-16">
          <path d="M0,40 C360,100 720,0 1080,60 C1260,80 1380,40 1440,40 L1440,100 L0,100 Z" fill="#2C3E2D" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Clinic Info */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#228B22] flex items-center justify-center">
                <PawPrint className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                زرازير البراري
              </h3>
            </div>
            <p className="text-white/70 text-sm leading-relaxed">
              {t
                ? "عيادة بيطرية متخصصة في رعاية الحيوانات الأليفة. نقدم أفضل الخدمات البيطرية بأيدي متخصصين."
                : "A specialized veterinary clinic for pet care. We provide the best veterinary services by expert hands."}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
              {t ? "روابط سريعة" : "Quick Links"}
            </h4>
            <ul className="space-y-2">
              {[
                { href: "/services", ar: "الخدمات", en: "Services" },
                { href: "/doctors", ar: "الأطباء", en: "Doctors" },
                { href: "/booking", ar: "حجز موعد", en: "Book Appointment" },
                { href: "/dashboard", ar: "لوحة التحكم", en: "Dashboard" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-white/70 hover:text-[#87CEEB] transition-colors text-sm cursor-pointer"
                  >
                    {t ? link.ar : link.en}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
              {t ? "تواصل معنا" : "Contact Us"}
            </h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-white/70 text-sm">
                <Phone className="w-4 h-4 text-[#87CEEB] flex-shrink-0" />
                <span dir="ltr">+964 770 123 4567</span>
              </li>
              <li className="flex items-center gap-3 text-white/70 text-sm">
                <Mail className="w-4 h-4 text-[#87CEEB] flex-shrink-0" />
                <span>info@zarazeer.iq</span>
              </li>
              <li className="flex items-center gap-3 text-white/70 text-sm">
                <MapPin className="w-4 h-4 text-[#87CEEB] flex-shrink-0" />
                <span>{t ? "كربلاء، العراق" : "Karbala, Iraq"}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/50 text-sm flex items-center gap-1">
            {t ? "صُنع بـ" : "Made with"}
            <Heart className="w-4 h-4 text-red-400 fill-red-400" />
            {t ? "بإدارة" : "Managed by"}
            <span className="text-[#87CEEB] font-medium">{t ? "فاطمة صلاح" : "Fatima Salah"}</span>
          </p>
          <p className="text-white/40 text-xs">
            © 2025 {t ? "زرازير البراري. جميع الحقوق محفوظة" : "Zarazeer Al-Barari. All rights reserved"}
          </p>
        </div>
      </div>
    </footer>
  );
}

