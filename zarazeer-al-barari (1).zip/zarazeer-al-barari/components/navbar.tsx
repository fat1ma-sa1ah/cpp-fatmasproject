"use client";
import { useState } from "react";
import Link from "next/link";
import { Menu, X, PawPrint, Globe, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NavbarProps {
  lang: "ar" | "en";
  onToggleLang: () => void;
}

const navLinks = {
  ar: [
    { href: "/", label: "الرئيسية" },
    { href: "/services", label: "الخدمات" },
    { href: "/doctors", label: "الأطباء" },
    { href: "/booking", label: "حجز موعد" },
    { href: "/contact", label: "التواصل" },
  ],
  en: [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/doctors", label: "Doctors" },
    { href: "/booking", label: "Book Now" },
    { href: "/contact", label: "Contact" },
  ],
};

export default function Navbar({ lang, onToggleLang }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const links = navLinks[lang];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg border-b border-[#D4C9A8]/50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group cursor-pointer">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#228B22] to-[#2D8F4E] flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105">
              <PawPrint className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#228B22]" style={{ fontFamily: "'Noto Naskh Arabic', serif" }}>
                زرازير البراري
              </h1>
              <p className="text-xs text-[#5A6B5C] -mt-1">
                {lang === "ar" ? "عيادة بيطرية متخصصة" : "Veterinary Clinic"}
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="px-4 py-2 rounded-xl text-[#2C3E2D] hover:bg-[#228B22]/10 hover:text-[#228B22] transition-all duration-200 font-medium text-sm cursor-pointer"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm text-[#5A6B5C] hover:bg-[#87CEEB]/20 hover:text-[#5CACDE] transition-all duration-200 cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              {lang === "ar" ? "EN" : "عربي"}
            </button>
            <Link href="/login">
              <Button className="bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl px-6 shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
                <User className="w-4 h-4 ml-2" />
                {lang === "ar" ? "تسجيل الدخول" : "Login"}
              </Button>
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button
            className="md:hidden p-2 rounded-xl hover:bg-[#F5ECD7] transition-colors cursor-pointer"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6 text-[#2C3E2D]" /> : <Menu className="w-6 h-6 text-[#2C3E2D]" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-6 pt-2 space-y-1 animate-in slide-in-from-top-2 duration-200">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-4 py-3 rounded-xl text-[#2C3E2D] hover:bg-[#228B22]/10 transition-colors font-medium cursor-pointer"
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="flex items-center gap-3 px-4 pt-3">
              <button
                onClick={onToggleLang}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm text-[#5A6B5C] hover:bg-[#87CEEB]/20 transition-colors cursor-pointer"
              >
                <Globe className="w-4 h-4" />
                {lang === "ar" ? "EN" : "عربي"}
              </button>
              <Link href="/login" className="flex-1">
                <Button className="w-full bg-[#228B22] hover:bg-[#1A6B1A] text-white rounded-2xl cursor-pointer">
                  <User className="w-4 h-4 ml-2" />
                  {lang === "ar" ? "تسجيل الدخول" : "Login"}
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

