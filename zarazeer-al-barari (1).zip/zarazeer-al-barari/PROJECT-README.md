# زرازير البراري - Zarazeer Veterinary Clinic

## 🌿 About
Professional veterinary clinic website with booking system.
Built with Next.js 16, TypeScript, Tailwind CSS 4, and shadcn/ui.

## 📁 Project Structure
- app/page.tsx - Home page
- app/booking/page.tsx - Appointment booking
- app/services/page.tsx - Veterinary services
- app/doctors/page.tsx - Doctor profiles
- app/contact/page.tsx - Contact info
- app/login/page.tsx - Login page
- app/dashboard/page.tsx - Admin dashboard
- components/navbar.tsx - Navigation bar
- components/footer.tsx - Footer

## 🚀 How to Run
1. npm install
2. npm run dev
3. Open http://localhost:3000

## 🌐 Live URL
https://zarazeer-clinic.codewords.run

## 👩‍💼 Managed by: Fatima Salah
